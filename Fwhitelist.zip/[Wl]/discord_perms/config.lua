-- Author : Fcore
-- Discord : https://discord.gg/jqS9qjdMj2

Config = {
	DiscordToken = "",
	GuildId = "",

	-- Format : ["Role Nickname"] = "Role ID" Vous pouvez obtenir l'identifiant du rôle en faisant \@RoleName
	Roles = {
		["Test"] = "" -- Cela serait vérifié en faisant exports.discord_perms:IsRolePresent(user, "TestRole")
	}
}
