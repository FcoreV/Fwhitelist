----------------------------------------
--- Discord Whitelist, Made by Fcore ---
----------------------------------------

fx_version 'bodacious'
game 'gta5'
server_only 'yes'
server_script 'server.lua'

author 'Fcore'
description 'Vous détestez mettre à jour ces listes blanches dautorisation ACE ? Eh bien, utilisez simplement Discord! Maintenant, vous pouvez grâce à ce script . Alors, gardez les listes blanches faciles et aérées. Ce script vérifie les rôles Discord des joueurs connectés et vérifie ils ont le rôle spécifié.'

